<template>
  <h1>Hello App!</h1>
  <p>
    <strong>Current route path:</strong> {{ $route.fullPath }}
  </p>
  <nav>
    <RouterLink to="/">Go to Home</RouterLink>
    <RouterLink to="/about">Go to About</RouterLink>
  </nav>
  <main id="app">
    <RouterView />
  </main>
</template>
<script>
import { RouterView } from 'vue-router';
export default{
  components:{
  RouterView
  }
}
</script>