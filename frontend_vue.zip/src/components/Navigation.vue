<template>
    <div class="navbar">
        <div class="navbar-logo">MyWebsite</div>
        <div>
        <a href="#home">Home</a>
        <a href="#news">News</a>
        <a href="#contact">Contact</a>
        <a href="#about">About</a>
        </div>
    </div>
</template>

<script setup>

</script>

<style>
</style>