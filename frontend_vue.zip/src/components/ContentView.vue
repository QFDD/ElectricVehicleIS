<template>
    <GameList />
</template>
  
<script>
  export default {
    name: 'ContentView',
    components: {
      GameList
    }
  }
</script>