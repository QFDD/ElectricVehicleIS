<template>
    <div class="list">
         <table>
            <colgroup>
                <col style="width:119px">
                <col>
                <col style="width:120px">
                <col style="width:100px">
                </colgroup>
            <thead>
                <th class="table-title" colspan="2"></th>
                <th class="text-center" ></th>
                <th class="text-center" ></th>
            </thead>
            <tbody>
                <tr class="game" >
                    <td>nihao</td>
                    <td>hha</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr></tr>
            </tbody>
        </table>
    </div>
</template>
  
<script>
  export default {
    name: 'ContentView',
    
  }
</script>